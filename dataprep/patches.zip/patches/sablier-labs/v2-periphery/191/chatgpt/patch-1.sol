pragma solidity >=0.8.19;

contract C {
    struct PackedData {
        uint128 x;
        uint128 y;
    }
    
    PackedData public data;
    uint256 public z;
}