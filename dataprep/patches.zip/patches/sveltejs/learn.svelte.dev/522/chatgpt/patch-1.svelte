<svg
    on:mousemove={(e) => {
        coords.set({ x: e.clientX, y: e.clientY });
    }}
    on:mousedown={() => size.set(30)}
    on:mouseup={() => size.set(10)}
>
    <circle
        cx={$coords.x}
        cy={$coords.y}
        r={$size}
        role="button" <!-- or "link", "image", or an appropriate role -->
    />
</svg>