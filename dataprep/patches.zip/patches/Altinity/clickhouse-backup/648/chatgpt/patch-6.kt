git rebase --continue
