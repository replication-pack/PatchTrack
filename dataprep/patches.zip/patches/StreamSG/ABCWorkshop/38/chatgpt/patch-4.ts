type ObjectWithHr = {
  type: 'hr';
  isHr: boolean;
};

type ObjectWithVariables = {
  type: 'variables';
  var1?: number;
  var2?: string;
  var3?: boolean;
};

type MyObject = ObjectWithHr | ObjectWithVariables;

const objects: MyObject[] = [
  { type: 'hr', isHr: true },
  { type: 'variables', var1: 10, var2: "hello", var3: true },
  { type: 'variables', var1: 20 },
  { type: 'variables', var2: "world" },
  { type: 'hr', isHr: true, var1: 5 } // This will now result in a type error
];
