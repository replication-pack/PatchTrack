function convertSecondsToMilliseconds(seconds: Second): Millisecond {
     return Millisecond.parse(seconds * 1000);
   }

   function convertSecondsToNanoseconds(seconds: Second): Nanosecond {
     return Nanosecond.parse(seconds * 1000000000);
   }

   const fiveSeconds: Second = Second.parse(5);
   const milliseconds = convertSecondsToMilliseconds(fiveSeconds);
   const nanoseconds = convertSecondsToNanoseconds(fiveSeconds);