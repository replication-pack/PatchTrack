import { z } from "zod";

   const Second = z.number().brand<"Second">();
   const Millisecond = z.number().brand<"Millisecond">();
   const Nanosecond = z.number().brand<"Nanosecond">();

   type Second = z.infer<typeof Second>;
   type Millisecond = z.infer<typeof Millisecond>;
   type Nanosecond = z.infer<typeof Nanosecond>;