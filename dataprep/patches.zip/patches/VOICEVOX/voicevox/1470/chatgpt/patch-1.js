// div要素を取得
let divElement = document.querySelector('div');

// イベントリスナーを追加（キャプチャフェーズ）
divElement.addEventListener('click', function(event) {
  console.log('div要素がクリックされました。');
}, true);
