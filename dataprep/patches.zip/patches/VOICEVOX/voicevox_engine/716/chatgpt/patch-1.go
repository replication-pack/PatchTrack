package main

import (
    "fmt"
    "os"
    "os/exec"
)

func main() {
    cmd := exec.Command("go", "test")
    cmd.Stderr = os.Stderr
    cmd.Stdout = os.Stdout

    if err := cmd.Run(); err != nil {
        fmt.Println("Tests failed")
        os.Exit(1)
    }
}
