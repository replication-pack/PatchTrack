if git diff --quiet; then
  echo "差分はありません"
else
  echo "差分があります"
fi