if diff file1.txt file2.txt > /dev/null; then
    echo "ファイルは同一です"
else
    case $? in
        1) echo "ファイルには差分があります" ;;
        2) echo "エラーが発生しました" ;;
    esac
fi