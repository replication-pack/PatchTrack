git rebase --abort
