git add <resolved-file>
