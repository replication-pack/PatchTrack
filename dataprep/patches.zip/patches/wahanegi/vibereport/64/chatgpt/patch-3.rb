results = ActiveRecord::Base.connection.execute("
  SELECT
    REGEXP_MATCHES(comment, '@(\d+)', 'g')
  FROM responses
")
