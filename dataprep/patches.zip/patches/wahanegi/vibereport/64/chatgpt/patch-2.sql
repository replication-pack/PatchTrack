SELECT
  REGEXP_MATCHES(comment, '@(\d+)', 'g')
FROM responses;
