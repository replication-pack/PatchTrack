# Get all comments from the responses table
comments = Response.pluck(:comment)

# Define regex pattern for @ followed by digits
pattern = /@(\d+)/

# Extract all user ID's into an array
user_ids = comments.map { |comment| comment.scan(pattern) }.flatten

# Convert all elements to integer (as they will be strings after the regex)
user_ids = user_ids.map(&:to_i)
