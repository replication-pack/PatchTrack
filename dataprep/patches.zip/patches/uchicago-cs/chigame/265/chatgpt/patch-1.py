# models.py
from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    token_count = models.IntegerField(default=0)
    last_token_addition = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.user.username