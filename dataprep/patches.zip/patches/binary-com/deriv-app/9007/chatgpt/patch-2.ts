type MyType = { something: string } | null;

let myArray: MyType[] = [ { something: "hello" }, null, { something: "world" }, null ];

const isNotNull = <T>(value: T | null): value is T => value !== null;

let filteredArray: { something: string }[] = myArray.filter(isNotNull);
